<?php
declare(strict_types=1);

// @deprecated Backwards compatibility alias. Will be removed in 5.0
class_alias('Cake\Database\TypeFactory', 'Cake\Database\Type');
